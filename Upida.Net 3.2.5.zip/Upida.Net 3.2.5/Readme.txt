Thank you for using Upida.

There are three examples:
1 - UpidaExampleAngular - This is advanced MVVM web application, extremely easy to implement and support.
This is also great example on how to create MVVM applications with angular.js and Upida.
This example shows you how to use Upida to create robust validation.

2 - UpidaExampleKnockout - This is advanced MVVM web application, extremely easy to implement and support.
This is also great example on how to create MVVM applications with knockout.js and Upida.
This example shows you how to use Upida to create robust validation.

3 - MyClients - This is advanced MVVM web application, extremely easy to implement and support.
This is also great example on how to create MVVM applications with angular.js and Upida.
This example shows you how to use Upida to create robust validation.

4 - UpidaExampleAngularEF - Same as UpidaExampleAngular, but uses Entity Framework instead of NHibernate.

You can start using Upida in your own projects.
The file "upida.angular.js" or "upida.knockout.js" can greatly simplify your efforts.
Copy this file to your project resources folder and start using it.
Don't forget to setup $upida.settings.baseUrl property to the home directory of your application (see app.js file in examples).

Good luck !