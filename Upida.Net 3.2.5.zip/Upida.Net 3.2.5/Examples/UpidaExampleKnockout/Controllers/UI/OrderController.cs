﻿using System.Web.Mvc;

namespace UpidaExampleKnockout.Controllers.UI
{
	public class OrderController : Controller
	{
		public ActionResult List()
		{
			return this.View();
		}

		public ActionResult Create()
		{
			return this.View();
		}

		public ActionResult Edit()
		{
			return this.View();
		}

		public ActionResult EditItems()
		{
			return this.View();
		}

		public ActionResult Show()
		{
			return this.View();
		}
	}
}