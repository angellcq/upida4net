﻿using System;

namespace Upida.Validation
{
	public enum Severity
	{
		None = 0,
		Low,
		High,
		Fatal
	}
}